from .property import ModbusPropertyView

__all__ = ('ModbusPropertyView',
           )
